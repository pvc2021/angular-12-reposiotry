import { Component, OnDestroy, OnInit } from '@angular/core';
import { Observable, Subscriber } from 'rxjs';

@Component({
  selector: 'app-angular-basics',
  templateUrl: './angular-basics.component.html',
  styleUrls: ['./angular-basics.component.css']
})
export class AngularBasicsComponent implements OnInit,OnDestroy {

title="Angular Basics";  //string

colors=['RED','GREEN','BLUE'];  //array

day:number=5; //number
min=1;  //number
max=8;  //number

show:boolean=true; //boolean
hide=false; //boolean

employee={
  id:101,
  name:'Pradeep chinchole',
  salary:12000.45333333,
  variable:0.14,
  mobile:'9158652627',
  pan:'sxndo9845f',
  gender:1,
  city:'Pune',
  doj:new Date()
};//object



today=new Observable((s:Subscriber<String>)=>{
   setInterval(()=>{
    s.next(new Date().toLocaleString());
  },1000);
  
});  //Observable





showHide(){
  this.hide=!this.hide;
}

  constructor() {
    console.log("===========AngularBasicsComponent created============");
   }

  ngOnDestroy(): void {
    console.log("===========AngularBasicsComponent destroyed============");
   
  }

  ngOnInit(): void {
    console.log("===========AngularBasicsComponent initialized============");
   
  }
}
