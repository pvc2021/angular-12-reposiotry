import { Directive, Input, TemplateRef, ViewContainerRef } from '@angular/core';

@Directive({
  selector: '[show]'
})
export class ShowDirective {

  constructor(private t:TemplateRef<any>,private vcr:ViewContainerRef) {
    console.log("===========ShowDirective created=======");
    }



    @Input()
    set show(value:boolean){
      console.log("In setShow method   :"+value);
      
      if(value)
      this.vcr.createEmbeddedView(this.t);
      else
      this.vcr.clear();
    }

}
