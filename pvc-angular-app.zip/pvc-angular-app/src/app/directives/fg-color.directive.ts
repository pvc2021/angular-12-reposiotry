import { Directive, ElementRef, Input, Renderer2 } from '@angular/core';

@Directive({
  selector: '[fgColor]'
})
export class FgColorDirective {

  constructor(private e:ElementRef<any>,private r:Renderer2) {
    console.log("=======FgColorDirective created=============");
   }

   @Input() 
   set fgColor(color:string){
     console.log("=========In setFgColor "+color);
     this.r.setStyle(this.e.nativeElement,"color",color);
   }


}
