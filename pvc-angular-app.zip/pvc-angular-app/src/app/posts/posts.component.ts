import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PostsService } from '../services/posts.service';

@Component({
  selector: 'app-posts',
  templateUrl: './posts.component.html',
  styleUrls: ['./posts.component.css']
})
export class PostsComponent implements OnInit {

title="All Posts"  
posts:any;
message=""
userId=0;


constructor(private ps:PostsService,private route:ActivatedRoute) {
    console.log("===========PostsComponent created============");
   }

  ngOnDestroy(): void {
    console.log("===========PostsComponent destroyed============");
   
  }

  ngOnInit(): void {
    this.userId=this.route.snapshot.queryParams.userId;
    console.log("===========PostsComponent initialized============");
   
   if(this.userId)
   this.getAllPostsByUserId();
   else
  this.getAllPosts();

  }


  getAllPosts(){
    this.ps.getAllPosts()
           .subscribe(response=>this.posts=response,error=>this.message=error);
  }


  getAllPostsByUserId(){
    this.ps.getAllPostsByUserId(this.userId)
           .subscribe(response=>this.posts=response,error=>this.message=error);
  }




}
