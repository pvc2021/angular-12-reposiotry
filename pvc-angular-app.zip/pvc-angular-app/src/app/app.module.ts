import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule,ReactiveFormsModule} from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AngularBasicsComponent } from './angular-basics/angular-basics.component';
import { AngularPipesComponent } from './angular-pipes/angular-pipes.component';
import { HomeComponent } from './home/home.component';
import { TechnologiesComponent } from './technologies/technologies.component';
import { UsersComponent } from './users/users.component';
import { PostsComponent } from './posts/posts.component';
import { CommentsComponent } from './comments/comments.component';
import { TodosComponent } from './todos/todos.component';
import { AlbumsComponent } from './albums/albums.component';
import { PhotosComponent } from './photos/photos.component';
import { UsersListComponent } from './users-list/users-list.component';
import { UsersTableComponent } from './users-table/users-table.component';
import { CaseStudyComponent } from './case-study/case-study.component';
import { CustomDirectivesComponent } from './custom-directives/custom-directives.component';
import { FgColorDirective } from './directives/fg-color.directive';
import { BgColorDirective } from './directives/bg-color.directive';
import { ShowDirective } from './directives/show.directive';
import { HideDirective } from './directives/hide.directive';
import { GenderPipe } from './pipes/gender.pipe';
import { OrderByPipe } from './pipes/order-by.pipe';
import {Ng2SearchPipeModule} from "ng2-search-filter";
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { NestedComponent } from './nested/nested.component';
import { CustomersComponent } from './customers/customers.component';
import { ViewchildComponent } from './viewchild/viewchild.component';
import { CountryComponent } from './country/country.component';
import { CityComponent } from './city/city.component';
import { StateComponent } from './state/state.component';
import { NumberComponent } from './number/number.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { PaginationComponent } from './pagination/pagination.component';
import { MustMatchDirective } from './directives/must-match.directive';

@NgModule({
  declarations: [  //components,directives,pipes
    AppComponent, AngularBasicsComponent, AngularPipesComponent, HomeComponent, TechnologiesComponent,
     UsersComponent, PostsComponent, CommentsComponent, TodosComponent, AlbumsComponent, PhotosComponent, 
     UsersListComponent, UsersTableComponent, CaseStudyComponent,
     CustomDirectivesComponent, FgColorDirective, BgColorDirective, ShowDirective, HideDirective, GenderPipe, OrderByPipe, ParentComponent, ChildComponent, NestedComponent, CustomersComponent, ViewchildComponent, CountryComponent, CityComponent, StateComponent, NumberComponent, LoginComponent, RegisterComponent, PaginationComponent, MustMatchDirective
  ],
  imports: [  //modules
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    Ng2SearchPipeModule,
    ReactiveFormsModule
  ],
  providers: [], //services
  bootstrap: [AppComponent],
//  bootstrap: [AppComponent,AngularBasicsComponent, AngularPipesComponent, HomeComponent, TechnologiesComponent]

})
export class AppModule { }
