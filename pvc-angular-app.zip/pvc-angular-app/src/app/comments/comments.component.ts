import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CommentsService } from '../services/comments.service';

@Component({
  selector: 'app-comments',
  templateUrl: './comments.component.html',
  styleUrls: ['./comments.component.css']
})
export class CommentsComponent implements OnInit {


  title="All Comments"  
  comments:any;
  message=""
  postId=0;
  
  
  constructor(private ps:CommentsService,private route:ActivatedRoute) {
      console.log("===========CommentsComponent created============");
     }
  
    ngOnDestroy(): void {
      console.log("===========CommentsComponent destroyed============");
     
    }
  
    ngOnInit(): void {

      this.postId=this.route.snapshot.queryParams.postId;

      console.log("===========CommentsComponent initialized============");
     if(this.postId)
     this.getAllCommentsByPostId();
     else     
     this.getAllComments();

    }
  
  
    getAllComments(){
      this.ps.getAllComments()
             .subscribe(response=>this.comments=response,error=>this.message=error);
    }
  
  
    getAllCommentsByPostId(){
      this.ps.getAllCommentsByPostId(this.postId)
             .subscribe(response=>this.comments=response,error=>this.message=error);
    }
  
  
}
