import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FgColorDirective } from '../directives/fg-color.directive';
import { NumberComponent } from '../number/number.component';

@Component({
  selector: 'app-viewchild',
  templateUrl: './viewchild.component.html',
  styleUrls: ['./viewchild.component.css']
})
export class ViewchildComponent implements OnInit {

@ViewChild(NumberComponent,{static:false})
private n:NumberComponent;

@ViewChild(FgColorDirective,{static:false})
private fg:FgColorDirective;

@ViewChild("name",{static:false}) 
private name:ElementRef;

@ViewChild("city",{static:false}) 
private city:ElementRef;



  ngOnInit(): void {
  }


  increaseNumber(){
   this.n.increment();


  }

  decreaseNumber(){
    this.n.decrement();
  }

  changeColor(){
    this.fg.fgColor="violet";
   }

   changeColors(){
    
    this.name.nativeElement.style.color="RED";
    this.name.nativeElement.style.backgroundColor="yellow";

    
    this.city.nativeElement.style.color="brown";
    this.city.nativeElement.style.backgroundColor="wheat";
    }
  
}
