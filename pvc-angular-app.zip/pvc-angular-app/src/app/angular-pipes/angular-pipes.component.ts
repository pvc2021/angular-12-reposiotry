import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-angular-pipes',
  templateUrl: './angular-pipes.component.html',
  styleUrls: ['./angular-pipes.component.css']
})
export class AngularPipesComponent implements OnInit {

  constructor() {
    console.log("===========AngularPipesComponent created============");
   }

  ngOnDestroy(): void {
    console.log("===========AngularPipesComponent destroyed============");
   
  }

  ngOnInit(): void {
    console.log("===========AngularPipesComponent initialized============");
   
  }

}
