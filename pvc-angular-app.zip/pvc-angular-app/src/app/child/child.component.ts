import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {

  message="Hello World";


  @Input()
  parentMessage="";


  @Output()
  childChanged=new EventEmitter<string>();  //It is used to fire event and emit the value
  
  constructor() {
    console.log("===========ChildComponent created============");
   }

  ngOnDestroy(): void {
    console.log("===========ChildComponent destroyed============");
   
  }

  ngOnInit(): void {
    console.log("===========ChildComponent initialized============");
   
  }



  sendMessageToParent(){
    this.childChanged.emit(this.message);
  }


}
