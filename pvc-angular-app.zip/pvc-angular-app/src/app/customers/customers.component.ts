import { Component, OnInit } from '@angular/core';
import { CustomersService } from '../services/customers.service';

@Component({
  selector: 'app-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.css']
})
export class CustomersComponent implements OnInit {

  title="Spring Boot Customer REST API"  
  customers:any;
  message=""
  customerId=0
  customer:any;

  update=false;
  add=false;
  
  constructor(private cs:CustomersService) {
      console.log("===========CustomersComponent created============");
      }
  
    ngOnDestroy(): void {
      console.log("===========CustomersComponent destroyed============");
     
    }
  
    ngOnInit(): void {
      console.log("===========CustomersComponent initialized============");
     
      this.getAllCustomers();
    }
  
  
    getAllCustomers(){
      this.cs.getAllCustomers()
             .subscribe(response=>this.customers=response,error=>this.message=error);
    }
  

    newCustomer(){
      
    this.customer={"customerId":0,
                  "name":"",
                  "pan":"",
                  "mobile":"",
                  "address":"",
                  "dob":""};

           this.add=false;
           this.update=true;

    }
  
   getCustomer(customerId:number){

    this.add=true;
    this.update=false;
           
      this.cs.getCustomersById(customerId)
             .subscribe(response=>this.customer=response,error=>this.message=error);
    }

    deleteCustomer(customerId:number){
      this.cs.deleteCustomersById(customerId)
             .subscribe(response=>this.customers=response,error=>this.message=error);
    }

   updateCustomer(customerId:number){
      this.cs.updateCustomersById(customerId,this.customer)
             .subscribe(response=>this.customers=response,error=>this.message=error);
             this.customer=null;
            
    }
   
   addCustomer(){
      this.cs.addCustomer(this.customer)
             .subscribe(response=>this.customers=response,error=>this.message=error);
    
            this.customer=null;

           }
      
}
