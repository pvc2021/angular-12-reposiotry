package com.pradeep.cms.service;

import java.util.Collection;

import com.pradeep.cms.domain.Customer;

public interface CustomerService {
	boolean saveCustomer(Customer customer);

	boolean updateCustomer(Customer customer);

	boolean deleteCustomer(int customerId);

	Customer findCustomer(int customerId);

	Collection<Customer> findAllCustomers();
}
